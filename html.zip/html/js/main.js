(function ($) {
"use strict";




// WOW active
new WOW().init();


})(jQuery);